<?php

if(!isset($_SESSION)) {
    session_start();
}

if(!isset($_SESSION['id'])) {
    die("Para acessar esta página, precisa estar logado.<p><a href=\"index.php\">Entrar</a></p>");
}


?>