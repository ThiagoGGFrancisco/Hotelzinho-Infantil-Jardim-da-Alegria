<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-br"></html>
    <head>
    <meta charset="utf-8">
        <link rel="shortcut icon" href="ico/logo.ico.ico">
        <title> Hotelzinho Infantil Jardim da Alegria </title>
        <link rel="stylesheet" href="/hotelzinho/css/style.css">
        <link rel="stylesheet" href="/hotelzinho/css/style_login.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <style type="text/css">
              @font-face {
        font-family: nicesugar;
        src: url(Nice\ Sugar.ttf)
    }
  
        </style>
    </head>
     <body>
       <h2> <ul id="menusuperior">
            <li class="vermelho"><a href=""> Início </a> </li>
            <li><a href="sobre.html"> Sobre </a> </li>
            <li><a href="sistema.php"> Volta </a>  </li>
            <li> <a href="sair.php">Sair</a>  </li>
            
            
             </ul></h2>

      <h1>Bem vindo <u> <?php echo $_SESSION['nome'] ?></u></h1>
 
        <br>

     </body>

    <div class="container my-6">
    <h1>
<?php
 
 include_once("conexao.php");

 $id = $_GET['id'];
?>

 <html>
 <head>
 <link href="estilos.css" rel="stylesheet" type="text/css">
 <title>Resultado da pesquisa</title>
 </head>
 <body>
 <div class="content">
 <!-- Criando tabela e cabeçalho de dados: -->
 <table border="1" style='width:80%'>
 <tr>
 <th>Id</th>
 <th>Nome</th>
 <th>Email</th>
 <th>Telefone</th>
 <th>Nível</th>
 </tr>
 
 <!-- Preenchendo a tabela com os dados do banco: -->
 <?php
 $sql = "SELECT * FROM cadastro WHERE id = '$id'";
 $resultado = mysqli_query($conexao,$sql) or die("Erro ao retornar dados");
 
 // Obtendo os dados por meio de um loop while
 while ($registro = mysqli_fetch_array($resultado))
 {
    $id = $registro['id'];
   $nome = $registro['nome'];
   $email = $registro['email'];
   $telefone = $registro['telefone'];
   $adm = $registro['adm'];
   echo "<tr>";
   echo "<td>".$id."</td>";
   echo "<td>".$nome."</td>";
   echo "<td>".$email."</td>";
   echo "<td>".$telefone."</td>";
   echo "<td>".$adm."</td>";
   echo "</tr>";
 }
 mysqli_close($conexao);
 echo "</table>";
?>
</h1>
    </div>
    </div>
</body>
</html>
            
        </div>
    </div>
</body>
</html>