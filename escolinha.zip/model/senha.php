

<?php  
      
if ( isset($_POST['submit']) ){
    
 include_once '../Model/altera.php' ;   

$cod_trecho= $_POST['email'];
$titulo_trecho= $_POST["senha_login"];
$trecho = $_POST["senha"];


$alterar = new crud();

$alterar->alterar_livro($cod_trecho,$titulo_trecho,$trecho);
}  

?><!DOCTYPE html>
<html lang="pt-br"></html>
<head>
<meta charset="UTF-8">     
<link rel="shortcut icon" href="ico/logo.ico.ico">
<title> Hotelzinho Infantil Jardim da Alegria </title>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="../hotelzinho/css/style_login.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<style type="text/css">
@font-face {
font-family: nicesugar;
src: url(Nice\ Sugar.ttf)
}
</style>
 
</head>
   <a class="navbar-brand" href="#">
          <img src="../hotelzinho/imagens/ico.png" width="100" height="100" class="d-inline-block align-top" alt="">
     Hotelzinho Infantil
     
        </a>
     
<body>
  
<h1><ul id="menusuperior">
<li class="vermelho"><a href="inicio.html"> Inicio </a> </li>
<li><a href="sobre.html"> Sobre </a> </li>
<li><a href="#"> Contato </a>  </li>
<li> <a href="login.php"> Login </a> </li>
</ul></h1>


<div class="container" >
<a class="links" id="paracadastro"></a>
<a class="links" id="paralogin"></a>
                            
<div class="content">                                      

<div id="cadastro">
<form method="post" action="login1.php"> 

</form>
</div>
<div id="login">    
<form action="login.php" method="POST">

<h1>Login</h1> 
<p> 
<h6>"Falha ao logar! E-mail ou senha incorretos"</h6> 
<label for="email_login">Seu e-mail:</label>
<input id="email_login" name="email" required="required" type="text" placeholder="contato@htmlecsspro.com"/>
</p>  
<p> 
<label for="senha_login">Sua senha:</label>
<input id="senha_login" name="senha" required="required" type="password" placeholder="1234" /> 
</p>
<p> 
<input class="inputSubmit" type="submit" name="submit" value="Enviar">                       
</p>

    <p class="link">
        Recupera senha?
        <a href="">Esqueci Senha</a>     
    </p> 

</form>
</div>                
</div>
</div> 
       

</body>
</html>