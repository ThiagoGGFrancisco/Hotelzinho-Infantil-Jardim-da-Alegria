<!DOCTYPE html>
<html lang="pt-br"></html>
<head>
<meta charset="UTF-8">  
<title> Hotelzinho Infantil Jardim da Alegria </title>
<link rel="stylesheet" href="assets/css/main1.css" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">



</style>
 
</head>


     
<body class="subpage">
        <div id="interface">

            <!-- Header -->
            <header id="header">
              <div class="logo"><a href="index.php"><span>Jardim da alegria</span></a></div>
              <a href="#menu">Menu</a>

            </header>
    <!-- Nav -->
    <nav id="menu">

        <ul class="links">
             <li><a href="index.php"> Home</a></li>
            <li><a href="login.php">login</a></li>
        </ul>
    </nav>
   
                    
<div class="content">   



<div class="row uniform">

<fieldset id="center-login">   
   
<div id="login">    
<form action="" method="POST">

<h1>Alterar senha</h1> 
<p> 

<label for="email_login">Seu e-mail:</label>
<input type="email" id="email" name="email" required="required" type="emailt" placeholder="contato@htmlecsspro.com"/>
</p>  
<p> 
<label for="senha_login">Nova Senha:</label>
<input id="senha" name="senha" required="required" type="password" placeholder="1234" /> 
</p>
<p> 
<label for="senha_login">Confimar senha:</label>
<input id="senha1" name="senha1" required="required" type="password" placeholder="1234" /> 
</p>

<p> 
<input class="inputSubmit" type="submit" name="submit" value="Alterar">                       
</p>
</form>
</div>          
</div>  


<?php
// Conexão com o banco de dados
 include_once('conexao.php');

// Verificar se o formulário de recuperação de senha foi enviado
if(isset($_POST['submit'])) {
   $email = $_POST['email'];
   $senha = $_POST['senha'];
   $confirma = $_POST['senha1'];


   // Verificar se o e-mail existe no banco de dados
   $query = "SELECT * FROM cadastro WHERE email = '$email'";
   $result = mysqli_query($conexao, $query);

   if(mysqli_num_rows($result) > 0) {
      // Gerar nova senha aleatória
      $nova_senha = substr(md5(uniqid(rand(), true)), 0, 8);
      $nova_senha_criptografada = sha1($nova_senha);

      // Atualizar a senha do usuário no banco de dados
      $query = "UPDATE cadastro SET senha = '$senha', confirma = '$confirma' WHERE email = '$email'";
      mysqli_query($conexao, $query);

      // Enviar nova senha por e-mail
      $assunto = "Recuperação de senha";
      $mensagem = "Sua nova senha é: " . $nova_senha;
      mail($email, $assunto, $mensagem);
      
      
      

      // Redirecionar para a página de login
      header("Location:  ../escolinha/login.php'");
   } else {
      // E-mail não encontrado
      echo "E-mail ainda sem cadastro.";

header("Location:  ");

   }
}
?>


<br>
<footer id="footer">
    <div class="container">

    </div>
    <div class="copyright">
         <a href="index.php" ><img src="imagens/iconesite.png" alt="" /></a><br>
         &copy; All rights reserved to Bit.
    </div>
</footer>
</body>



<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
            <script src="assets/js/jquery.scrollex.min.js"></script>
            <script src="assets/js/skel.min.js"></script>
            <script src="assets/js/util.js"></script>
            <script src="assets/js/main.js"></script>
</html>











