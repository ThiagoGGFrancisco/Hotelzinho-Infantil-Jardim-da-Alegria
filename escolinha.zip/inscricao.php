<?php

if(isset($_POST['submit']))
{

include_once('conexao.php');

$turma = $_POST['turma'];
$nome = $_POST['nome'];
$email = $_POST['email'];
$crianca = $_POST['crianca'];
$van = $_POST['van'];
$telefone = $_POST['telefone'];
$endereco = $_POST['endereco'];
$data_nasc = $_POST['data'];
$convernio = $_POST['convenio'];
$result = mysqli_query($conexao, "INSERT INTO inscricao ( turma,nome,email,crianca,van,telefone,endereco,data_nascimento,convernio) 
VALUES ( '$turma','$nome','$email','$crianca','$van','$telefone','$endereco ','$data_nasc','$convernio')");

        
header('Location: index.php');
}
?>


<!DOCTYPE html>
<html lang="pt-br"></html>
<head>
<meta charset="UTF-8">  
<title> Hotelzinho Infantil Jardim da Alegria </title>
<link rel="stylesheet" href="assets/css/main1.css" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">



</style>
 
</head>


     
<body class="subpage">
        <div id="interface">

            <!-- Header -->
            <header id="header">
              <div class="logo"><a href="index.php"><span>Jardim da alegria</span></a></div>
              <a href="#menu">Menu</a>

            </header>
    <!-- Nav -->
    <nav id="menu">

        <ul class="links">
             <li><a href="index.php"> Home</a></li>
            <li><a href="login.php">login</a></li>
        </ul>
    </nav>
   
<form action="" method="POST">                      
<div class="content">   



<div class="row uniform">

<fieldset id="center-login">   
   


<h2>Pré matricula aluno</h2> 


<label for="turma" class="labelInput">Turma:</label>
<select name="Turma" type="text" name="turma" id="turma" class="inputUser" required >
                <option value="">Selecione</option>
                <option value="1"> bebês (zero a 1 ano e 6 meses)</option>
                <option value="2"> crianças pequenas (4 anos a 5 anos e 11 meses)</option>
                <option value="2">crianças pequenas (4 anos a 5 anos e 11 meses)</option>
                
</select>


<label for="nome" class="labelInput">Nome do responsável:</label>

<div class="inputBox">
<input type="text" name="nome" id="nome" class="inputUser" required placeholder="Nome do responsável."/>
</div>

<label for="email" class="labelInput">E-mail:</label>             
<div class="inputBox">
<input type="email" name="email" id="email" class="inputUser" required placeholder="Email do responsavel " />

</div>
                
<label for="crianca" class="labelInput">Nome do aluno:</label>
<div class="inputBox">
    <input type="text" name="crianca" id="crianca" class="inputUser" required placeholder="Nome da criança."/>
</div>

<label for="van" class="labelInput">Van escolar:</label>
<div class="inputBox">
    <input type="text" name="van" id="van" class="inputUser" required placeholder="Caso utilizar van Escolar"/>
</div>

<label for="telefone" class="labelInput">Telefone</label>
<div class="inputBox">
    <input type="number" name="telefone" id="telefone" class="inputUser" required placeholder="(00)00000-0000"/>
</div>

<label for="endereco" class="labelInput">Endereço:</label>
    <div class="inputBox">
<input type="text" name="endereco" id="endereco" class="inputUser" required placeholder="Endereço do responável"/>
</div>

<label for="data" class="labelInput">Nascimento da criança:</label>
    <div class="inputBox">
<input type="date" name="data" id="data" class="inputUser" required placeholder="Data de nascimento da criança"/>
</div>

<label for="convenio" class="labelInput">Convenio:</label>
    <div class="inputBox">
<input type="text" name="convenio" id="convenio" class="inputUser" required placeholder=" Forma convenio."/>


</div>
<br>

    <input type="submit" name="submit" id="submit">
</fieldset>
</form>
</div>

</div>
</div>

<br>
<footer id="footer">
    <div class="container">

    </div>
    <div class="copyright">
         <a href="index.php" ><img src="imagens/iconesite.png" alt="" /></a><br>
         &copy; All rights reserved to Bit.
    </div>
</footer>
</body>

<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
            <script src="assets/js/jquery.scrollex.min.js"></script>
            <script src="assets/js/skel.min.js"></script>
            <script src="assets/js/util.js"></script>
            <script src="assets/js/main.js"></script>
</html>