
<?php
session_start();
include('protect.php');
?>

<!DOCTYPE html>
<html lang="pt-br"></html>
<head>
<meta charset="UTF-8">     
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="assets/css/main1.css" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<style type="text/css">
@font-face {
font-family: nicesugar;
src: url(Nice\ Sugar.ttf)
}
</style>
 
</head>
<title>Jardim da alegria</title>


     
<body class="subpage">
        <div id="interface">

            <!-- Header -->
           
            <header id="header">
              <div class="logo"><a href=""><span>Jardim da alegria</span></a></div>
              
              <a href="#menu">Menu</a>

            </header>
    <!-- Nav  menu -->
    <nav id="menu">

        <ul class="links">
            <br>
             <h4>Bem vindo <u> <?php echo $_SESSION['nome'] ?></u></h4>
             <br>
            <li ><a href="rematricula.php">Rematrícula</a> </li>
            <li > <a href="atividade.php">Vídeos Educacionais</a> </li>
           <li> <a href="https://calendar.google.com/calendar/u/1/r?pli=1"target="_blank" > Agenda </a> </li>
            <li > <a href="https://api.whatsapp.com/send?phone=5519987075090&app" target="_blank"
                                "> Falar com a direção </a></li>
            <li> <a href="sair.php">Sair</a>  </li><br>
           
        </ul>
    </nav>

  <br><br>
        </style>




<body>
<div class="container" >
<div class="content"> 
        <h1>Minha Atividade</h1><br><br>
        <?php
        if(isset($_SESSION['msg'])){
            echo $_SESSION['msg'];
            unset($_SESSION['msg']);
        }
        ?>
        <div class="container">
        
       
        <form method="POST" action="img.php" enctype="multipart/form-data">
        <label>Nome: </label>
        <input type="text" name="nome" placeholder="Nome Atividade"><br><br>

        <label>E-mail: </label>
        <input type="text" name="email" placeholder="Digite seu E-mail"><br><br>

        <label>Imagens</label>
        <input type="file" name="imagens[]" multiple="multiple"><br><br><br><br>

        <input type="submit" name="SendCadUser" value="Enviar"><br><br>
    </form>
    
</div>
</div>

</body>
    <!-- Scripts -->
            <script src="assets/js/jquery.min.js"></script>
            <script src="assets/js/jquery.scrollex.min.js"></script>
            <script src="assets/js/skel.min.js"></script>
            <script src="assets/js/util.js"></script>
            <script src="assets/js/main.js"></script>

</div>                
</div>
</div> 
<br>

