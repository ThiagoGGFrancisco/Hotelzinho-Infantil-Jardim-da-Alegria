
<?php
session_start();
include('protect.php');
?>

<!DOCTYPE html>
<html lang="pt-br"></html>
<head>
<meta charset="UTF-8">     
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="assets/css/main1.css" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<style type="text/css">
@font-face {
font-family: nicesugar;
src: url(Nice\ Sugar.ttf)
}
</style>
 
</head>
<title>Jardim da alegria</title>


     
<body class="subpage">
        <div id="interface">

            <!-- Header -->
           
            <header id="header">
              <div class="logo"><a href=""><span>Jardim da alegria</span></a></div>
              
              <a href="#menu">Menu</a>

            </header>
    <!-- Nav  menu -->
    <nav id="menu">

        <ul class="links">
             <h4>Bem vindo <u> <?php echo $_SESSION['nome'] ?></u></h4>
            <li><a href=""> Home</a></li><br>
            <li > <a href="rematricula.php"><b> Rematricula </b> </a> </li>
            <li > <a href="atividade.php"><b> Atividade </b> </a> </li>
           <li><a href="sistema.php"> Volta </a>  </li><br>
           <li> <a href="https://calendar.google.com/calendar/u/1/r?pli=1"target="_blank" ><b> Calendário </b></a> </li>
            <li> <a href="https://www.google.com/maps/place/Av.+Santo+Irineu,+459+-+Jardim+das+Oliveiras+(Nova+Veneza),+Sumar%C3%A9+-+SP,+13180-170/@-22.8350775,-47.1626773,17z/data=!3m1!4b1!4m6!3m5!1s0x94c8bf397ff7e6b7:0x4b00bff181f386ff!8m2!3d-22.8350775!4d-47.1604886!16s%2Fg%2F11gc9h0ch6" target="_blank"  #ea272a; text-decoration: none;"> Endereço </b> </a></li>
            <li> <a href="sair.php">Sair</a>  </li><br>
           
        </ul>
    </nav>

  
        </style>







    
    

<body>
<div class="container" >
<div class="content"> 
        <h1>Cadastrar Atividade</h1>
        <?php
        if(isset($_SESSION['msg'])){
            echo $_SESSION['msg'];
            unset($_SESSION['msg']);
        }
        ?>
        <div class="container">
        
       
        <form method="POST" action="img.php" enctype="multipart/form-data">
        <label>Nome: </label>
        <input type="text" name="nome" placeholder="Nome Atividade"><br><br>

        <label>E-mail: </label>
        <input type="data" name="email" placeholder="data"><br><br>

        <label>Imagens</label>
        <input type="file" name="imagens[]" multiple="multiple"><br><br>

        <input type="submit" name="SendCadUser" value="Cadastrar"><br><br>
    </form>
    
</div>
</div>

</body>
    <!-- Scripts -->
            <script src="assets/js/jquery.min.js"></script>
            <script src="assets/js/jquery.scrollex.min.js"></script>
            <script src="assets/js/skel.min.js"></script>
            <script src="assets/js/util.js"></script>
            <script src="assets/js/main.js"></script>

</div>                
</div>
</div> 
<br>
<footer id="footer">
    <div class="container">

    </div>
    <div class="copyright">
         <a href="index.php" ><img src="imagens/iconesite.png" alt="" /></a><br>
         &copy; All rights reserved to Bit.
    </div>
</footer>

s