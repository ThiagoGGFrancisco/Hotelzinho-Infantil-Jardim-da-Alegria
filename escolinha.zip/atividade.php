
<?php
session_start();
include('protect.php');
?>

<!DOCTYPE html>
<html lang="pt-br"></html>
<head>
<meta charset="UTF-8">     
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="assets/css/main1.css" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<style type="text/css">
@font-face {
font-family: nicesugar;
src: url(Nice\ Sugar.ttf)
}
</style>
 
</head>
<title>Jardim da alegria</title>


     
<body class="subpage">
        <div id="interface">

            <!-- Header -->
           
            <header id="header">
              <div class="logo"><a href=""><span>Jardim da alegria</span></a></div>
              
              <a href="#menu">Menu</a>

            </header>
    <!-- Nav  menu -->
    <nav id="menu">

        <ul class="links">
             <h4>Bem vindo <u> <?php echo $_SESSION['nome'] ?></u></h4><br>
          <li><a href="rematricula.php"> Rematrícula </a>  </li>
           <li><a href="painel.php"> Cadastro de Atividade </a>  </li>
           <li> <a href="https://calendar.google.com/calendar/u/1/r?pli=1"target="_blank" >
                Agenda</a> </li>
            <li><a href="https://api.whatsapp.com/send?phone=5519987075090&app" target="_blank" 
                                "> Falar con a Direção </a>  </li>
            <li> <a href="sair.php">Sair</a>  </li><br>
           
        </ul>
 
</div>


  

	 <br><br>
	 <div class="container">
        <button type="button" class="btn btn-outline-warning">
        <div class="title">Video educacional.</div>
        
        <br>
          <div class="row">
            
            <div class="col align-self-center">
            <iframe width="300" height="215" src="https://www.youtube.com/embed/Vb2--oI5UcU?start=1" title="
        YouTube video player" frameborder="0" allow="accelerometer; 
        autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen class="rounded-circle"></iframe>    </div>
        
            <div class="col align-self-end">
               <iframe width="300" height="215" src="https://www.youtube.com/embed/hCMD1c88IZQ" title="YouTube video player"
                     frameborder="0" allow="accelerometer; autoplay; clipboard-write;
                     encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen class="rounded-circle"></iframe>
            </div>
            <div class="col align-self-center">
            <iframe width="300" height="215" <iframe width="560" height="315" src="https://www.youtube.com/embed/p05PaGx4m3Q" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreenallowfullscreen class="rounded-circle"></iframe>
       </div>
       
            <div class="col align-self-end">
               <iframe width="300" height="215" <iframe width="560" height="315" src="https://www.youtube.com/embed/bl2aoIFTUEA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen class="rounded-circle"></iframe>
            </div>
          </div>
	
	 <!-- Scripts -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/jquery.scrollex.min.js"></script>
        <script src="assets/js/skel.min.js"></script>
        <script src="assets/js/util.js"></script>
        <script src="assets/js/main.js"></script>
</html>
