<?php
session_start();
include('protect.php');
?>

<!DOCTYPE html>
<html lang="pt-br"></html>
<head>
<meta charset="UTF-8">     
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="assets/css/main1.css" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<style type="text/css">
@font-face {
font-family: nicesugar;
src: url(Nice\ Sugar.ttf)
}
</style>
 
</head>
<title>Jardim da alegria</title>
<br><br>
<div class="container">


<body class="subpage">
        <div id="interface">

            <!-- Header -->
            
            <header id="header">
              <div class="logo"><a href=""><span>Jardim da alegria</span></a></div>
              
              <a href="#menu">Menu</a>

            </header>
    <!-- Nav  menu -->
    <nav id="menu">

        <ul class="links">
            <h4>Bem vindo <u> <?php echo $_SESSION['nome'] ?></u></h4><br>
            
           <li><a href="colaborador.php"> Colaborador </a>  </li><br>
            <li> <a href="sair.php">Sair</a>  </li><br>
           
           <?php

date_default_timezone_set('America/Sao_Paulo');
$hora = date('h:i:s A');
$mes1=array(jan,feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec);
$mes2=array(Jan,Fev,Mar,Abr,Mai,Jun,Jul,Ago,Set,Out,Nov,Dez);
$mestexto=array(Janeiro,Fevereiro,Março,Abril,Maio,Junho,Julho,Agosto,Setembro,Outubro,Novembro,Dezembro);
$hour=date('H');
$mestext=str_ireplace($mes1,$mestexto,date('d/M/Y'));
$data=str_ireplace($mes1,$mes2,date('d/M/Y'));

if ($hour < 12) echo "<span style=\"color:red;\">BOM DIA</span><BR>";
else if ($hour < 18) echo "<span style=\"color:green;\">BOA TARDE</span><BR>";
 else if ($hour < 24) echo "<span style=\"color:blue;\">BOA NOITE</span><BR>";
 
 echo("$data $hora <br> $mestext");

?>

        </ul>
    </nav>


        </style>
    
      

<br><br><br><br><br><br>



		<form action="" method="POST">
			<table border="1">
			<tr><td>Data:</td><td><input type="text" name="data" /><br></td></tr>
			<tr><td>quantidade de aulas:</td><td><input type="text" name="qtd" /><br></td></tr>
			<tr><td colspan="2"><input type="submit" value="Submeter"/></td></tr>
			</table>
		</form>
</div>
     
<table border="1">
		<tr>
			<th>ID</th>
			<th>Nome</th>
			<th>Frequencia</th>
			<th>Quantidade de Aulas</th>
		</tr>
		
<?php
	require_once('conexao.php');
	if($_POST!=null){
	$aux = 0;
	$data = $_POST['data'];
	if($data!=""){
		echo "<br>A Data de hoje é : " . $data . "<br><br>";
	}else{
		echo "<br><b>Usuário não informou a data</b><br><br>";
	}
	$query = "select * from aulas";
	
	$resultado = mysqli_query($conexao , $query);
	
	while($array = mysqli_fetch_array($resultado)){
?>	
	<tr>
		<td><?php echo $array[0] ?></td>
		<td><?php echo $array[1] ?></td>
		<td><?php echo $array[2] ?></td>
		
		<?php $valor = $_POST['qtd']; 
		
		echo "<form action='insere.php' method='get'>";
		echo"<td>";
		for($i=0;$i<$valor;$i++){
			$aux++;
			$aux2 = "$i";
			echo "<input type='checkbox' name='opcao[]$aux2' value='$aux'/>";
		}
		echo "</td>";
		?>  <td><?php echo $data['adm']; ?></td>
		
		</tr>
		
	<?php
		}
		
	?>
		
	</table>
	
</form>
		<?php  
			 $sql = mysqli_query($conexao , "SELECT * FROM aulas");
			 $t = mysqli_num_rows($sql);
			 if($t > 0){ 
			 	echo"<input type='hidden' name='qtd' id='qtd' value='$valor'/>";
			}else{
			 	$valor = 0;
			 	echo"<input type='hidden' name='qtd' id='qtd' value='$valor'/>";
	
		}?>
		
		<input type="submit" value="Enviar"/><br>
	</form>
	
	<?php
	}else{
		echo "<h1>SEM NADA PRA MOSTRAR, INSIRA DADOS</h1>";
	}
	mysqli_close($conexao);
	
	?>
	<a href="info.php">Voltar</a>







    <!-- Scripts -->
            <script src="assets/js/jquery.min.js"></script>
            <script src="assets/js/jquery.scrollex.min.js"></script>
            <script src="assets/js/skel.min.js"></script>
            <script src="assets/js/util.js"></script>
            <script src="assets/js/main.js"></script>

</div>                
</div>
</div> 
<br>



  </script>  
</body>
</html>