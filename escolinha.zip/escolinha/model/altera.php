<?php

public function alterar_livro($cod_trecho, $titulo_trecho,$trecho){

    $conexao= conectar(); 
    
  	$pegacod_trecho = mysqli_query($conn, "SELECT * FROM cadastro WHERE cod_trecho = '$cod_trecho'");

         if(mysqli_num_rows($pegacod_trecho) == 0){

	    	echo "<script language='javascript' type='text/javascript'>alert('Este Código NÃO esta cadastrado em nossos registros');window.location.href='../hotelzinho/hotelzinho/recupera_senha.php.php'</script>";

	      }else{		

		
          $result_livro = "UPDATE cadastro SET titulo_trecho = '$titulo_trecho', trecho = '$trecho' WHERE cod_trecho = '$cod_trecho'";

         mysqli_query($conexao,$result_livro);

             if(mysqli_affected_rows($conn) != 0){
            echo "

                 <script language='javascript' type='text/javascript'>alert('Trecho do Livro alterado com sucesso!');window.location.href='../View/frm_livro.php'</script>";
                 
            
             }else{
                  echo " 
                   <script language='javascript' type='text/javascript'>alert('Nao foi possivel alterar este trecho');window.location.href='../View/frm_alterar.php'</script>";
                     
                  
                     
              }


        }




   }
  }

?>