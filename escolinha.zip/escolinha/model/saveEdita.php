<?php
    // isset -> serve para saber se uma variável está definida
    include_once('conexao.php');
    if(isset($_POST['update']))
    {
        $id = $_POST['id'];
        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $telefone = $_POST['telefone'];
        $cidade = $_POST['adm'];
       
        
        $sqlInsert = "UPDATE cadastro
        SET nome='$nome',email='$email',telefone='$telefone',adm='$cidade'
        WHERE id=$id";
        $result = $conexao->query($sqlInsert);
        print_r($result);
    }
    header('Location: /hotelzinho/hotelzinho/lista.php');

?>