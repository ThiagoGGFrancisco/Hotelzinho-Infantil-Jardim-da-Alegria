<?php
session_start();
include('protect.php');
?>

<!DOCTYPE html>
<html lang="pt-br">

</html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="assets/css/main1.css" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <style type="text/css">
        @font-face {
            font-family: nicesugar;
            src: url(Nice\ Sugar.ttf)
        }
    </style>

</head>
<title>Jardim da alegria</title>



<body class="subpage">
    <div id="interface">

        <!-- Header -->

        <header id="header">
            <div class="logo hide-logo"><a href="index.php"><img src="imagens/iconesite.png" alt="" /></a><br></div>


            <a href="#menu">Menu</a>

        </header>
        <!-- Nav  menu -->
        <nav id="menu">

            <ul class="links">
                <h4>Seja bem-vindo, <u>
                        <?php echo $_SESSION['nome'] ?>
                    </u></h4>
                    <li><a href="sistema.php">Cadastrar novo usuário</a></li>
                    <li><a href="lista.php">Editar/Consultar usuário</a></li>
                    <li ><a href="inser.aviso.php">inserir aviso e vídeo educativo</a> </li>
                    <li ><a href="nova.turma.php">NOVAS TURMAS</a> </li>
                    <li ><a href="nova.turma.php">TURMAS</a> </li>
                    <li ><a href="anexo.php">pais</a>   </li>
                    <li ><a href="relatorio.php">relatório</a> </li>
                    <li> <a href="sair.php">Sair</a>  </li>
                <?php

                date_default_timezone_set('America/Sao_Paulo');
                $hora = date('h:i:s A');
                $mes1 = array('jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec');
                $mes2 = array('Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez');
                $mestexto = array('Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro');
                $hour = date('H');
                $mestext = str_ireplace($mes1, $mestexto, date('d/M/Y'));
                $data = str_ireplace($mes1, $mes2, date('d/M/Y'));

                if ($hour < 12)
                    echo "<span style=\"color:red;\">BOM DIA</span><BR>";
                else if ($hour < 18)
                    echo "<span style=\"color:green;\">BOA TARDE</span><BR>";
                else if ($hour < 24)
                    echo "<span style=\"color:blue;\">BOA NOITE</span><BR>";

                echo ("$data $hora <br> $mestext");

                ?>
            </ul>
        </nav>
        <br><br>

        </style>

        <div class="content">
            <form action="saveEdita.php" method="POST">
                <fieldset>
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-warning">
                                <h4 class="text-center text-light">Editar dados do usuário: </h4>

                            </div>



                            <?php

                            include_once("conexao.php");
                            $id = $_GET['id'];
                            ?>
                            <div class="inputBox">
                                <h3 class="text-center text-light"><label for="" class="labelInput">Id
                                        <?php echo $id; ?>
                                    </label></h3>
                            </div>

                            <div class="inputBox">

                                <input type="text" name="nome" id="nome" class="inputUser" value=<?php echo $nome; ?>
                                    Nome Completo>
                                <label for="nome" class="labelInput">Nome completo</label>
                            </div>

                            <div class="inputBox">
                                <input enail="text" name="email" id="email" class="inputUser" value=<?php echo $email; ?>
                                    seuemail@dominio.com>
                                <label for="email" class="labelInput">E-mail</label>
                            </div>

                            <div class="inputBox">
                                <input type="tel" name="telefone" id="telefone" class="inputUser" value=<?php echo $telefone; ?> (00) 00000-0000>
                                <label for="telefone" class="labelInput">Telefone</label>
                            </div>

                            <div class="inputBox">
                                <input type="text" name="adm" id="adm" class="inputUser" value=<?php echo $adm; ?> Nível>
                                <label for="cidade" class="labelInput">Nível</label>
                            </div>

                            <input type="hidden" name="id" value=<?php echo $id; ?>>
                            <input type="submit" name="update" id="submit" value=" EDITAR">
                </fieldset>
            </form>
        </div>

        <br>


        <div class="content">
            <div class="card">
                <div class="container mt-5">
                    <div class="card-header bg-warning">
                        <h4 class="text-center text-light">Minha consulta de cadastro:</h4><br>
                    </div>
                    <form name="Cadastro" action="listageral.php" method="POST">
                        <label>Pesquisa de usuário por nível de acesso:</label>
                        <select name="adm">
                            <option value=""> Seleciona o nível de usuário</option>
                            <option value="0"> 0-Responsável</option>
                            <option value="1"> 1-Professor</option>
                            <option value="2"> 2-Administrador</option>
                        </select><br>
                        <input type="submit" name="enviar" value="CONSULTAR">
                    </form>
                </div>
            </div>
        </div>
        <br>





        <div class="content">
            <div class="col-12">
                <div class="card">


                    </tbody>
                    </table>
                </div>

                <?php
                include_once('conexao.php');

                if (!empty($_GET['id'])) {
                    $id = $_GET['id'];
                    $sqlSelect = "SELECT * FROM cadastro WHERE id=$id";
                    $result = $conexao->query($sqlSelect);
                    if ($result->num_rows > 0) {
                        while ($user_data = mysqli_fetch_assoc($result)) {
                            $id = $user_data['id'];
                            $nome = $user_data['nome'];
                            $email = $user_data['email'];
                            $telefone = $user_data['telefone'];
                            $adm = $user_data['adm'];

                        }
                    } else {
                        header('Location:');
                    }
                } else {
                    header('Location: ');
                }
                ?>

                <br>


                <div class="content">
                    <fieldset>
                        <div class="col-12">

                            <header class="d-flex justify-content-between my-4">
                                <h1>Lista dos Cadastros:</h1>

                            </header>
                            <?php

                            if (isset($_SESSION["create"])) {
                                ?>
                                <div class="alert alert-success">
                                    <?php
                                    echo $_SESSION["create"];
                                    ?>
                                </div>
                                <?php
                                unset($_SESSION["create"]);
                            }
                            ?>
                            <?php
                            if (isset($_SESSION["update"])) {
                                ?>
                                <div class="alert alert-success">
                                    <?php
                                    echo $_SESSION["update"];
                                    ?>
                                </div>
                                <?php
                                unset($_SESSION["update"]);
                            }
                            ?>
                            <?php
                            if (isset($_SESSION["delete"])) {
                                ?>
                                <div class="alert alert-success">
                                    <?php
                                    echo $_SESSION["delete"];
                                    ?>
                                </div>
                                <?php
                                unset($_SESSION["delete"]);
                            }

                            ?>

                            <?php

                            include_once("conexao.php");

                            $id = $_GET['id'];
                            ?>

                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Nome Completo</th>
                                        <th>E-mail </th>
                                        <th>Data de Inclusão</th>
                                        <th>Nível</th>
                                        <th>Deletar</th>
                                        <th>Editar</th>

                                    </tr>
                                </thead>

                                <?php
                                include('conexao.php');
                                $sqlSelect = "SELECT * FROM cadastro ORDER BY id DESC";
                                $result = mysqli_query($conexao, $sqlSelect);
                                while ($data = mysqli_fetch_array($result)) {
                                    ?>
                                    <tr>
                                        <td>
                                            <?php echo $data['id']; ?>

                                        <td>
                                            <?php echo $data['nome']; ?>
                                        </td>
                                        <td>
                                            <?php echo $data['email']; ?>
                                        </td>
                                        <td>
                                            <?php echo $data['data']; ?>
                                        </td>
                                        <td>
                                            <?php echo $data['adm']; ?>
                                        </td>

                                        <td><a href="model/delete.php?id=<?php echo $data['id']; ?>"
                                                class="botao btn-danger"><svg xmlns="http://www.w3.org/2000/svg" width="16"
                                                    height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                                    <path
                                                        d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5Zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5Zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6Z" />
                                        </td>
                                        <td>
                                            <path
                                                d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1ZM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118ZM2.5 3h11V2h-11v1Z" />
                                            </svg></a>
                                        </td>

                                        <td><a href="?id=<?php echo $data['id']; ?>" class="botao btn-warning" i><svg
                                                    xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                                    fill="currentColor" class="bi bi-pen" viewBox="0 0 16 16">
                                                    <path
                                                        d="m13.498.795.149-.149a1.207 1.207 0 1 1 1.707 1.708l-.149.148a1.5 1.5 0 0 1-.059 2.059L4.854 14.854a.5.5 0 0 1-.233.131l-4 1a.5.5 0 0 1-.606-.606l1-4a.5.5 0 0 1 .131-.232l9.642-9.642a.5.5 0 0 0-.642.056L6.854 4.854a.5.5 0 1 1-.708-.708L9.44.854A1.5 1.5 0 0 1 11.5.796a1.5 1.5 0 0 1 1.998-.001zm-.644.766a.5.5 0 0 0-.707 0L1.95 11.756l-.764 3.057 3.057-.764L14.44 3.854a.5.5 0 0 0 0-.708l-1.585-1.585z" />
                                                </svg></a></td>

                                    </tr>
                                    <?php
                                }
                                ?>
                                </tbody>
                            </table>





                        </div>
                </div>
                <!-- Scripts -->
                <script src="assets/js/jquery.min.js"></script>
                <script src="assets/js/jquery.scrollex.min.js"></script>
                <script src="assets/js/skel.min.js"></script>
                <script src="assets/js/util.js"></script>
                <script src="assets/js/main.js"></script>

            </div>
        </div>
    </div>
    <br>


    </script>
</body>

</html>