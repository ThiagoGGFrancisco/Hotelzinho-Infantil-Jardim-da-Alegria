<!DOCTYPE html>

<html>
    <head>
        <title>Hotelzinho Infantil</title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" href="assets/css/main1.css" />

    </head>
    <body>

        <!-- Header -->
        <header id="header" class="alt">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
            <div class="logo hide-logo"><a href="index.php"><img src="imagens/iconesite.png" alt="" /></a><br></div>

            <a href="#menu">Menu</a>
        </header>

        <!-- Nav -->
        <nav id="menu" >

            <ul id="menusuperior" class="links">
                  <?php
             
                session_start();

                if (isset($_SESSION["log"])) {
                    echo"Seja bem-vindo,". $_SESSION["usuario"];
                    
                }
                ?>
                <li><a href="index.php">Home</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="inscricao.php">Matrículas abertas </a></li>         

            </ul>
            
            
              <?php

date_default_timezone_set('America/Sao_Paulo');
$hora = date('h:i:s A');
$mes1=array('jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec');
$mes2=array('Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez');
$mestexto=array('Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro');
$hour=date('H');
$mestext=str_ireplace($mes1,$mestexto,date('d/M/Y'));
$data=str_ireplace($mes1,$mes2,date('d/M/Y'));

if ($hour < 12) echo "<span style=\"color:red;\">BOM DIA</span><BR>";
else if ($hour < 18) echo "<span style=\"color:green;\">BOA TARDE</span><BR>";
 else if ($hour < 24) echo "<span style=\"color:blue;\">BOA NOITE</span><BR>";
 
 echo("$data $hora <br> $mestext");

?>
        </nav>

        <!-- Banner -->
       <section class="banner full">
            <article>
                <img src="imagens/principal.png" alt="" />
                <div class="inner">
                    <header><br><br>
                        <p>Segurança, conforto, disciplina, consciência e muita diversão!</p>
                        <h2>Hotelzinho infantil</h2>
                    </header>
                </div>
            </article>
            <article>
                <img src="imagens/saladeaula.jpg" alt="" />
                <div class="inner">
                    <header>
                        <p>Matricule seu filho de maneira fácil e rápido , pré-matrícula online </p>
                        <h2> Matrículas abertas</h2>
                    </header>
                </div>
            </article>
            <article>
                <img src="imagens/imagem3.jpg"  alt="" />
                <div class="inner">
                    <header>
                        <p>Somos uma escola particular, mas aceitamos tambem o convênio com a prefeitura da cidade</p>
                        <h2>Particular e Conveniado </h2>
                    </header>
                </div>
            </article>
            <article>
                <img src="imagens/Fofo.jpg"  alt="" />
                <div class="inner">
                    <header>
                        <p> Temos uma equipe especializada para dar o melhor suporte e apoio nesse momento tão importante. </p>
                        <h2>Jardim da alegria</h2>
                    </header>
                </div>
            </article>
            
        </section>

        <!-- One -->
        <section id="one" class="wrapper style2">
            <div class="inner">
                <div class="grid-style">
                    
                    <div>
                        <div class="box">
                            <div class="image fit">
                                <img src="imagens/matricula1.png" alt=""  width="50" height="300" />
                            </div>
                            <div class="content">
                                <header class="align-center">
                                    <p>Pré-matrícula</p>
                                    <h2>Matrículas abertas</h2>
                                
                                </header>
                                <p class="align-center">Venha fazer parte desta turma !  </p>
                                <footer class="align-center">
                                    <a href="inscricao.php" class="button alt">INSCREVA-SE</a>
                                </footer>
                            </div>
                        </div>
                    </div>

                    <div>
                        <div class="box">
                            <div class="image fit">
                                <img src="imagens/Logo.png" alt=""  width="300" height="300" />
                            </div>
                            <div class="content">
                                <header class="align-center">
                                    <p>Jardim da alegria</p>
                                    <h2>Turmas</h2>
                                </header>
                                <p class="align-center"> Conheça nossas turmas aqui! </p>
                                <footer class="align-center">
                                    <a href="turmas.php" class="button alt">CONHECER</a>
                                </footer>
                            </div>
                        </div>
                    </div>

                    <div>
                        <div class="box">
                            <div class="image fit">
                                <img src="imagens/whatsapsite.png" alt=""  width="300" height="300" />
                            </div>
                            <div class="content">
                                <header class="align-center">
                                    <p>Jardim da alegria</p>
                                    <h2>Fale Conosco</h2>
                                </header>
                                <p class="align-center">Você não acha que o seu filho tem direito ao melhor? Então entre em contato com a gente! </p>
                                <footer class="align-center">
                                    <a href="https://api.whatsapp.com/send?phone=5519987075090&app" target="_blank" class="button alt">CLIQUE AQUI</a>
                                </footer>
                            </div>
                        </div>   
                    </div>

                    <div>
                        <div class="box">
                            <div class="image fit">
                                <img src="imagens/endereco.png" alt="" width="300" height="300" />
                            </div>
                            <div class="content">
                                <header class="align-center">
                                    <p>Jardim da alegria</p>
                                    <h2>Localização do Jardim da Alegria</h2>
                                </header>
                                <p class="align-center">Faça sua visita em nossa escola! </p>
                                <footer class="align-center">
                                    <a href="https://www.google.com/maps/place/Av.+Santo+Irineu,+459+-+Jardim+das+Oliveiras+(Nova+Veneza),+Sumar%C3%A9+-+SP,+13180-170/@-22.8350775,-47.1626773,17z/data=!3m1!4b1!4m6!3m5!1s0x94c8bf397ff7e6b7:0x4b00bff181f386ff!8m2!3d-22.8350775!4d-47.1604886!16s%2Fg%2F11gc9h0ch6" target="_blank" class="button alt">COMO CHEGAR</a>
                                </footer>
                            </div>
                        </div>
                    </div>

                    <div>
                        <div class="box">
                            <div class="image fit">
                                <img src="imagens/raposinha.png" alt="" width="300" height="300" />
                            </div>
                            <div class="content">
                                <header class="align-center">
                                    <p>Jardim da alegria</p>
                                    <h2>Sobre Jardim da Alegria</h2>
                                </header>
                                <p class="align-center">   Saiba mais sobre a escola</p>
                                <footer class="align-center">
                                    <a href="Sobre.php" class="button alt">SAIBA MAIS</a>
                                </footer>
                            </div>
                        </div>
                    </div>

                    <div>
                        <div class="box">
                            <div class="image fit">
                                <img src="imagens/redesocial.png" alt="" width="300" height="300" />
                            </div>
                            <div class="content">
                                <header class="align-center">
                                    <p>Jardim da alegria</p>
                                    <h2>Facebook Jardim da Alegria </h2>
                                </header>
                                <p class="align-center"> Nossas redes sociais estão abertas para nos conhecer </p>
                                <footer class="align-center">
                                    <a href="https://www.facebook.com/Hotelzinho-Infantil-Jardim-da-Alegria-1785110238450229/" target="_blank" class="button alt">SAIBA MAIS</a>
                                    <!--   <li class="botao"> <a href="https://www.facebook.com/Hotelzinho-Infantil-Jardim-da-Alegria-1785110238450229/" target="_blank"><b> Nossas Redes </b> </a></li> -->
                                </footer>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>

        <!-- Footer -->
        <footer id="footer">
            <div class="container">

            </div>
            <div class="copyright">
                <a href="index.php" ><img src="imagens/iconesite.png" alt="" /></a><br>
                &copy; All rights reserved to BIT.
            </div>
        </footer>


        <!-- Scripts -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/jquery.scrollex.min.js"></script>
        <script src="assets/js/skel.min.js"></script>
        <script src="assets/js/util.js"></script>
        <script src="assets/js/main.js"></script>

    </body>
</html>
