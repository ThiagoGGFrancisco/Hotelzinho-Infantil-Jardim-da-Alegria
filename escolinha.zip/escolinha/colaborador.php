<?php
session_start();
include('protect.php');
?>

<!DOCTYPE html>
<html lang="pt-br"></html>
<head>
<meta charset="UTF-8">     
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="assets/css/main1.css" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<style type="text/css">
@font-face {
font-family: nicesugar;
src: url(Nice\ Sugar.ttf)
}
</style>
 
</head>
<title>Jardim da alegria</title>


     
<body class="subpage">
        <div id="interface">

            <!-- Header -->
           
            <header id="header">
              <div class="logo hide-logo"><a href="index.php"><img src="imagens/iconesite.png" alt="" /></a><br></div>

              
              <a href="#menu">Menu</a>

            </header>
    <!-- Nav  menu -->
    <nav id="menu">

        <ul class="links">
              <h4>Seja bem-vindo, <u> <?php echo $_SESSION['nome'] ?></u></h4>
            <li><a href="chamada.php"> Chamada</a></li>
            <li><a href="list.php">Atividade entregues</a></li>
            <li> <a href="sair.php">Sair</a>  </li>
            <?php

date_default_timezone_set('America/Sao_Paulo');
$hora = date('h:i:s A');
$mes1=array(jan,feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec);
$mes2=array(Jan,Fev,Mar,Abr,Mai,Jun,Jul,Ago,Set,Out,Nov,Dez);
$mestexto=array(Janeiro,Fevereiro,Março,Abril,Maio,Junho,Julho,Agosto,Setembro,Outubro,Novembro,Dezembro);
$hour=date('H');
$mestext=str_ireplace($mes1,$mestexto,date('d/M/Y'));
$data=str_ireplace($mes1,$mes2,date('d/M/Y'));

if ($hour < 12) echo "<span style=\"color:red;\">BOM DIA</span><BR>";
else if ($hour < 18) echo "<span style=\"color:green;\">BOA TARDE</span><BR>";
 else if ($hour < 24) echo "<span style=\"color:blue;\">BOA NOITE</span><BR>";
 
 echo("$data $hora <br> $mestext");

?>
        </ul>
    </nav>

</body><br>
    
     
<div class="container">
        <h1 class="text-center">Cadastro de Atividade</h1><br>
       
        <form method="POST" action="arquivo.php" enctype="multipart/form-data">
        <label>Nome da Atividade: </label>
        <input type="text" name="nome" placeholder="Nome"><br><br>

        <label>Data Final de Entrega: </label>
        <input type="date" name="email" placeholder=""><br><br>

        <label>Upload de Arquivo</label>
        <input type="file" name="imagens[]" multiple="multiple"><br><br><br>

        <input type="submit" name="SendCadUser" value="Cadastrar"><br><br>
    </form>
    

    
</body>

        <!-- Scripts -->
            <script src="assets/js/jquery.min.js"></script>
            <script src="assets/js/jquery.scrollex.min.js"></script>
            <script src="assets/js/skel.min.js"></script>
            <script src="assets/js/util.js"></script>
            <script src="assets/js/main.js"></script>

</script>
</html>