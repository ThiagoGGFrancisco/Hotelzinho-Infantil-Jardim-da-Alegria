<?php
session_start();
include('protect.php');
?>

<!DOCTYPE html>
<html lang="pt-br"></html>
<head>
<meta charset="UTF-8">     
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="assets/css/main1.css" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<style type="text/css">
@font-face {
font-family: nicesugar;
src: url(Nice\ Sugar.ttf)
}
</style>
 
</head>
<title>Jardim da alegria</title>


     
<body class="subpage">
        

            <!-- Header -->
           
            <header id="header">
              <div class="logo hide-logo"><a href="index.php"><img src="imagens/iconesite.png" alt="" /></a><br></div>

              
              <a href="#menu">Menu</a>

            </header>
    <!-- Nav  menu -->
    <nav id="menu">

        <ul class="links">
            <br>
              <h4>Seja bem-vindo, <u> <?php echo $_SESSION['nome'] ?></u></h4>
             <br>
             <li > <a href="painel.php">Avisos e Vídeos Educacionais</a> </li>
             <li > <a href="myatividade.php">Minhas Atividades</a> </li>
            <li ><a href="rematricula.php">Rematrícula</a> </li>
            
         <li> <a href="https://calendar.google.com/calendar/u/1/r/week/2023/5/10" target="_blank"> Agenda </a> </li>
            <li > <a href="https://api.whatsapp.com/send?phone=5519987075090&app" target="_blank"
                                > Falar com a direção </a></li>
            <li> <a href="sair.php">Sair</a>  </li><br>
           
        </ul>
    </nav>

  <br><br>
        </style>

</head>
<title>Jardim da alegria</title>


     
<body class="subpage">
        <div id="interface">

            <!-- Header -->
           
            <header id="header">
              <div class="logo"><a href=""><span>Jardim da alegria</span></a></div>
              
              <a href="#menu">Menu</a>

            </header>
    <!-- Nav  menu -->
    <nav id="menu">

        <ul class="links">
             <h4>Seja bem-vindo, <u> <?php echo $_SESSION['nome'] ?></u></h4><br>
          <li><a href="rematricula.php"> Rematrícula </a>  </li>
           <li><a href="painel.php"> Cadastro de Atividade </a>  </li>
           <li><a href="atestado.php"> ANEXAR ATESTADO MÉDICO </a>  </li>
           <li> <a href="https://calendar.google.com/calendar/u/1/r?pli=1"target="_blank" >
                Agenda</a> </li>
            <li><a href="https://api.whatsapp.com/send?phone=5519987075090&app" target="_blank"> Falar com a Direção </a>  </li>
            <li> <a href="sair.php">Sair</a>  </li><br>
           
        </ul>
        </nav>

        <div class="container" >

        <h1>Meu atestado:</h1><br><br>
        <?php
        if(isset($_SESSION['msg'])){
            echo $_SESSION['msg'];
            unset($_SESSION['msg']);
        }
        ?>
        <div class="container">
        
       
        <form method="POST" action="img.php" enctype="multipart/form-data">
        <label>Nome do aluno: </label>
        <input type="text" name="nome" placeholder="Nome Atividade"><br><br>

        <label>Quantidade de dias ausentes: </label>
        <input type="text" name="email" placeholder="Digite seu E-mail"><br><br>
        <input type="number" min="0" max="2" class="form-control" maxlength="1"
        id="usercontact" name="user_adm" placeholder="Dias ausentes "autocomplete="off" required="required" pattern="[0-9]+$" />
                                        </div>

        <label>Justificativa: </label>
        <input type="text" name="email" placeholder="Digite seu E-mail"><br><br>

        <label>Upload de Arquivo</label>
        <input type="file" name="imagens[]" multiple="multiple"><br><br><br><br>

        <input type="submit" name="SendCadUser" value="ENVIAR"><br><br>
    </form>
    
</div>
</div>



    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.scrollex.min.js"></script>
    <script src="assets/js/skel.min.js"></script>
    <script src="assets/js/util.js"></script>
    <script src="assets/js/main.js"></script>