<?php

if(isset($_POST['submit']))
{

include_once('conexao.php');

$turma = $_POST['turma'];
$nome = $_POST['nome'];
$email = $_POST['email'];
$crianca = $_POST['crianca'];
$van = $_POST['van'];
$telefone = $_POST['telefone'];
$endereco = $_POST['endereco'];
$data_nasc = $_POST['data'];
$convernio = $_POST['convenio'];
$result = mysqli_query($conexao, "INSERT INTO inscricao ( turma,nome,email,crianca,van,telefone,endereco,data_nascimento,convernio) 
VALUES ( '$turma','$nome','$email','$crianca','$van','$telefone','$endereco ','$data_nasc','$convernio')");

        
header('Location: index.php');
}
?>


<!DOCTYPE html>
<html lang="pt-br"></html>
<head>
<meta charset="UTF-8">  
<title> Hotelzinho Infantil Jardim da Alegria </title>
<link rel="stylesheet" href="assets/css/main1.css" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">



</style>
 
</head>


     
<body class="subpage">
        <div id="interface">

            <!-- Header -->
            <header id="header">
              <div class="logo"><a href="index.php"><img src="imagens/iconesite.png" alt="" /></a></div>
              <a href="#menu">Menu</a>

            </header>
    <!-- Nav -->
    <nav id="menu">

        <ul class="links">
             <li><a href="index.php"> Home</a></li>
            <li><a href="login.php">login</a></li>
        </ul>
    </nav>
   
<form action="" method="POST">                      
<div class="content">   



<div class="row uniform">

<fieldset id="center-login">   
   


<h7>PREENCHA SEU INTERESSE DE VAGA</h7> 
<br>
<br>
<label for="turma" class="labelInput">TURMA:</label>
<select name="Turma" type="text" name="turma" id="turma" class="inputUser" required >
                <option value="">Selecione a turma por idade</option>
                <option value="1"> Berçário + 3 meses </option>
                <option value="2"> Maternal + 1 ano</option>
                <option value="3">Maternal II   de 2 até 3 anos</option>
                <option value="4">Pré-escola I até 4 anos</option>
                <option value="5">Pré-escola II até 5 anos</option>
                
</select>

<label for="periodo" class="labelInput">PERÍODO:</label>
<select name="Periodo" type="text" name="periodo" id="periodo" class="inputUser" required >
                <option value="">Selecione o período do seu interesse</option>
                <option value="1">Integral 7h-17h20</option>
                <option value="2">Meio período -Manhã 7h-12h20 </option>
                <option value="3">Meio período- Tarde 13h-17h20</option>
                
</select>

<label for="crianca" class="labelInput">NOME DO ALUNO:</label>
<div class="inputBox">
    <input type="text" name="crianca" id="crianca" class="inputUser" required placeholder="Nome da criança."/>
</div>

<label for="data" class="labelInput">DATA DE NASCIMENTO ALUNO:</label>
    <div class="inputBox">
<input type="date" name="data" id="data" class="inputUser" required placeholder="Data de nascimento da criança"/>
</div>

<label for="nome" class="labelInput">NOME DO RESPONSÁVEL:</label>

<div class="inputBox">
<input type="text" name="nome" id="nome" class="inputUser" required placeholder="Nome do responsável."/>
</div>

<label for="email" class="labelInput">E-MAIL:</label>             
<div class="inputBox">
<input type="email" name="email" id="email" class="inputUser" required placeholder="Email do responsavel " />
</div>

<label for="telefone" class="labelInput">TELEFONE 1:</label>
<div class="inputBox">
    <input type="number" name="telefone" id="telefone" class="inputUser" required placeholder="(00)00000-0000"/>
</div>

<label for="telefone" class="labelInput">TELEFONE 2:</label>
<div class="inputBox">
    <input type="number" name="telefone" id="telefone" class="inputUser" required placeholder="(00)00000-0000"/>
</div>

<label for="endereco" class="labelInput">ENDEREÇO:</label>
    <div class="inputBox">
<input type="text" name="endereco" id="endereco" class="inputUser" required placeholder="Endereço do responável"/>
</div>

<label class="labelInput">TRANSPORTE ESCOLAR:</label>
<div class="inputBox">
    <input type="radio" id="naoTransporte" name="transporte" value="nao" class="inputUser" required>
    <label for="naoTransporte">Não</label>

    <input type="radio" id="simTransporte" name="transporte" value="sim" class="inputUser" required>
    <label for="simTransporte">Sim</label>
    <label for="simTransporte" class="sim">Qual?  <input type="text" class="inputUser" required placeholder="Inserir nome e telefone"/></label>
   
</div>

<label for="convenio" class="labelInput">CONVENIO COM PREFEITURA</label>
    <div class="inputBox">
    <div class="inputBox">
    <input type="radio" id="naoConvenio" name="convenio" value="naoConvenio" class="inputUser" required>
    <label for="naoConvenio">Não</label>

    <input type="radio" id="simConvenio" name="convenio" value="simConvenio" class="inputUser" required>
    <label for="simConvenio">Sim</label>


</div>
<br>

    <input type="submit" name="submit" id="submit"  value="ENVIAR">
</fieldset>
</form>
</div>

</div>
</div>

<br>
<footer id="footer">
    <div class="container">

    </div>
    <div class="copyright">
         <a href="index.php" ><img src="imagens/iconesite.png" alt="" /></a><br>
         &copy; All rights reserved to Bit.
    </div>
</footer>
</body>

<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
            <script src="assets/js/jquery.scrollex.min.js"></script>
            <script src="assets/js/skel.min.js"></script>
            <script src="assets/js/util.js"></script>
            <script src="assets/js/main.js"></script>
</html>