<?php

if(isset($_POST['submit']))
{

include_once('conexao.php');

$turma = $_POST['turma'];
$periodo = $_POST['periodo'];
$crianca = $_POST['crianca'];
$data_nasc = $_POST['data'];
$nome = $_POST['nome'];
$email = $_POST['email'];
$telefone = $_POST['telefone'];
$telefone1 = $_POST['telefone1'];
$endereco = $_POST['endereco'];
$sim = $_POST['sim'];
$nao = $_POST['nao'];
$van= $_POST['van'];
$convernio = $_POST['naoconvenio'];
$convernio1 = $_POST['simconvenio'];

$result = mysqli_query($conexao, "INSERT INTO inscricao ( turma,periodo,crianca,data_nascimento,nome,email,telefone,telefone1,endereco,sim,nao,van,convernio,convernio1 ) 
VALUES ( '$turma','$periodo','$crianca','$data_nasc','$nome','$email','$telefone','$telefone1','$endereco ','$sim','$nao','$van','$convernio','$convernio1 ')");header('Location: index.php');
}
?>





<!DOCTYPE html>
<html lang="pt-br"></html>
<head>
<meta charset="UTF-8">  
<title> Hotelzinho Infantil Jardim da Alegria </title>
<link rel="stylesheet" href="assets/css/main1.css" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">



</style>
 
</head>


     
<body class="subpage">
        <div id="interface">

            <!-- Header -->
            <header id="header">
              <div class="logo"><a href="index.php"><img src="imagens/iconesite.png" alt="" /></a></div>
              <a href="#menu">Menu</a>

            </header>
    <!-- Nav -->
    <nav id="menu">

        <ul class="links">
             <li><a href="index.php"> Home</a></li>
            <li><a href="login.php">login</a></li>
        </ul>
    </nav>
   
<form action="" method="POST">                      
<div class="content">   



<div class="row uniform">

<fieldset id="center-login">   
   


<h7>PREENCHA SEU INTERESSE DE VAGA</h7> 
<br>
<br>
<label for="turma" class="labelInput">TURMA:</label>
<select name="turma" type="text" name="turma" id="turma" class="inputUser" required >
                <option value="">Selecione a turma por idade</option>
                <option value=" Bercario"> Ber&ccedil;ario + 3 meses </option>
                <option value="Maternal"> Maternal + 1 ano</option>
                <option value="Maternal II">Maternal II   de 2 at&eacute; 3 anos</option>
                <option value="Pre-escola I">Pre&eacute;-escola I at&eacute; 4 anos</option>
                <option value="Pre-escola II">Pr&eacute;-escola II at&eacute; 5 anos</option>
                
</select>

<label for="periodo" class="labelInput">PER&Iacute;DO:</label>
<select name="periodo" type="text" name="periodo" id="periodo" class="inputUser" required >
                <option value="">Selecione o per&iacute;odo do seu interesse</option>
                <option value="Integral">Integral 7h-17h20</option>
                <option value="Meio per&iacute;odo -Manha">Meio período- Manhã 12h20 </option>
                <option value="Meio per&iacute;odo- Tarde">Meio período- Tarde 13h-17h20</option>
                
</select>
<label for="crianca" class="labelInput">NOME DO ALUNO:</label>
<div class="inputBox">
    <input type="text" name="crianca" id="crianca" class="inputUser"   maxlength="50"required placeholder="Nome da crian&ccedil;a."/>
</div>

<label for="data" class="labelInput">DATA DE NASCIMENTO ALUNO:</label>
    <div class="inputBox">
<input type="date" name="data" id="data" class="inputUser" required placeholder="Data de nascimento da crian�a"/>
</div>

<label for="nome" class="labelInput">NOME DO RESPONS&Agrave;VEL:</label>

<div class="inputBox">
<input type="text" name="nome" id="nome" class="inputUser"maxlength="50" required placeholder="Nome do respons&agrave;vel."/>
</div>

<label for="email" class="labelInput">E-MAIL:</label>             
<div class="inputBox">
<input type="email" name="email" id="email" class="inputUser" required placeholder="Email do responsavel " />
</div>

<label for="telefone" class="labelInput">TELEFONE 1:</label>
<div class="inputBox">
    <input type="tel" name="telefone" id="telefone" class="inputUser"maxlength="12" required placeholder="(00)00000-0000"/>
</div>

<label for="telefone" class="labelInput">TELEFONE 2:</label>
<div class="inputBox">
    <input type="tel" name="telefone1" id="telefone1" class="inputUser"maxlength="12" required placeholder="(00)00000-0000"/>
</div>

<label for="endereco" class="labelInput">ENDERE&Ccedil;O:</label>
    <div class="inputBox">
<input type="text" name="endereco" id="endereco" class="inputUser"maxlength="50" required placeholder="Endere&ccedil;o do respon&agrave;vel"/>
</div>

<label class="labelInput">TRANSPORTE ESCOLAR:</label>
<div class="inputBox">
    <input type="radio" id="sim" name="sim" value="sim" class="inputUser" >
    <label for="sim">Sim</label>

    <input type="radio" id="nao" name="nao" value="nao" class="inputUser" >
    <label for="nao">Não</label>
    <label for="sim" class="sim">Qual? 
    <input type="text" name="van" id="van" class="inputUser" maxlength="20" placeholder="Inserir nome e telefone"/></label>
   
</div>
<label for="convenio" class="labelInput">CONVENIO COM PREFEITURA</label>
    <div class="inputBox">
    <div class="inputBox">
    <input type="radio" id="naoConvenio" name="naoconvenio" value="naoConvenio" class="inputUser" >
    <label for="naoConvenio">Não</label>

    <input type="radio" id="simConvenio" name="simconvenio" value="simConvenio" class="inputUser" >
    <label for="simConvenio">Sim</label>


</div>
<br>

    <input type="submit" name="submit" id="submit"  value="ENVIAR">
</fieldset>
</form>
</div>

</div>
</div>

<br>
<footer id="footer">
    <div class="container">

    </div>
    <div class="copyright">
         <a href="index.php" ><img src="imagens/iconesite.png" alt="" /></a><br>
         &copy; All rights reserved to Bit.
    </div>
</footer>
</body>

<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
            <script src="assets/js/jquery.scrollex.min.js"></script>
            <script src="assets/js/skel.min.js"></script>
            <script src="assets/js/util.js"></script>
            <script src="assets/js/main.js"></script>
</html>