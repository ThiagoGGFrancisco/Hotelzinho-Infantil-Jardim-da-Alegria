﻿<html>
		<form action="chamada.php" method="POST">
			<table border="1">
			<tr><td>Data:</td><td><input type="text" name="data" /><br></td></tr>
			<tr><td>quantidade de aulas:</td><td><input type="text" name="qtd" /><br></td></tr>
			<tr><td colspan="2"><input type="submit" value="Submeter"/></td></tr>
			</table>
		</form>
</html>