<?php
	session_start();

?>

<!DOCTYPE html>
<html lang="pt-br"></html>
<head>
<meta charset="UTF-8">     
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="assets/css/main1.css" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<style type="text/css">
@font-face {
font-family: nicesugar;
src: url(Nice\ Sugar.ttf)
}
</style>
 
</head>
<title>Jardim da alegria</title>
<form action="login1.php" method="POST">
     
<body class="subpage">
        <div id="interface">

            <!-- Header -->
            <header id="header">
               <div class="logo hide-logo"><a href="index.php"><img src="imagens/iconesite.png" alt="" /></a><br></div>

              <a href="#menu">Menu</a>

            </header>
    <!-- Nav  menu -->
    <nav id="menu">

        <ul class="links">
            <li><a href="index.php"> Home</a></li>
            <li><a href="inscricao.php">Matrículas abertas</a></li>
        </ul>
        
          <?php

date_default_timezone_set('America/Sao_Paulo');
$hora = date('h:i:s A');
$mes1=array('jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec');
$mes2=array('Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez');
$mestexto=array('Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro');
$hour=date('H');
$mestext=str_ireplace($mes1,$mestexto,date('d/M/Y'));
$data=str_ireplace($mes1,$mes2,date('d/M/Y'));

if ($hour < 12) echo "<span style=\"color:red;\">BOM DIA</span><BR>";
else if ($hour < 18) echo "<span style=\"color:green;\">BOA TARDE</span><BR>";
 else if ($hour < 24) echo "<span style=\"color:blue;\">BOA NOITE</span><BR>";
 
 echo("$data $hora <br> $mestext");

?><br>
    </nav>

    
<form action="login1.php" method="POST">
           
<br><br><br>
  
     
  
        <a class="links" id="paralogin"></a>
                             
        <div class="content">                                      
        <div id="cadastro">

        <h2>Login</h2> <br>
        <p> 
        <label for="email_login">Seu e-mail:</label>
        <input type="text" name="email" id="email_login"  placeholder="Digite o email do usuario" required/></p>
        </p>  
        <p> <br>
            
        <label for="senha_login">Sua senha:</label>
        <input type = "password" id="senha_login" name="senha" required="required" type="password" placeholder="Digite sua senha" /> 
        </p>
      
        <p>
        <input class="inputSubmit" type="submit" name="submit" value="Entrar">                       
        </p>
        <br><br>
        <p class="link">
            Esqueceu sua senha?
            <a href="recupera_senha.php">Recuperar senha</a>     
        </p> 
    <fieldset>
</div>

</form>
<br><br><br><br><br>

            <!-- Scripts -->
            <script src="assets/js/jquery.min.js"></script>
            <script src="assets/js/jquery.scrollex.min.js"></script>
            <script src="assets/js/skel.min.js"></script>
            <script src="assets/js/util.js"></script>
            <script src="assets/js/main.js"></script>

</div>                
</div>
</div> 

<footer id="footer">
    <div class="container">

    </div>
    <div class="copyright">
         <a href="index.php" ><img src="imagens/iconesite.png" alt="" /></a><br>
         &copy; All rights reserved to Bit.
    </div>
</footer>

</body>
</html>