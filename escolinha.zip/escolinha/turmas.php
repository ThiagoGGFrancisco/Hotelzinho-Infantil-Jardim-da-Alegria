<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Jardim da alegria</title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" href="assets/css/main1.css" />
    </head>


    <body class="subpage">
        <div id="interface">
            <!-- Header -->
            <header id="header">

                 <div class="logo hide-logo"><a href="index.php"><img src="imagens/iconesite.png" alt="" /></a><br></div>

                <a href="#menu">Menu</a>
            </header>

            

            <!-- Nav -->
            <nav id="menu">

                <ul class="links">
                    <?php
                    
                   


                    if (isset($_SESSION["log"])) {
                        echo"Bem vindo " . $_SESSION["usuario"];
                    }
                    ?>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="Login.php">Login</a></li>               
                    <li><a href="Sair.php">Sair</a></li>

                </ul>
            </nav>
            <div>
                <div class="box">

                    <div class="content">
                        <header class="align-center">
                            <p></p>
                            <h2></h2>
                        </header>
                        <style>
                            p{
                                text-align: justify;
                                text-align: center;
                            }
                           
                        </style>
                        <p style="text-align: justify">Bem-vindo ao site da nossa escola infantil Jardim da Alegria!</p>
                        <p style="text-align: justify"> Na nossa escola, temos horários de turmas flexíveis para atender às necessidades das famílias e dos alunos.</p>
                        <p style="text-align: justify">Todas as turmas contam com atividades pedagógicas, recreativas e de lazer, além de alimentação balanceada e saudável. Na turma integral, os alunos têm acompanhamento durante 
todo o período e participam de atividades extracurriculares que complementam a sua formação.
Os horários de entrada e saída dos alunos são organizados de forma a garantir a segurança e o bem-estar de todos, com profissionais capacitados e experientes para recebê-los e 
acompanhá-los durante todo o período escolar.
Cada turma é formada por alunos de faixas etárias similares, com atividades adequadas ao seu desenvolvimento cognitivo, motor, socioafetivo e cultural. Nossos profissionais são 
altamente qualificados e dedicados a oferecer um atendimento personalizado a cada aluno, respeitando as suas individualidades e necessidades.
Entre em contato conosco para conhecer mais sobre a nossa proposta pedagógica e as nossas turmas. Estamos à disposição para esclarecer quaisquer dúvidas e ajudá-lo a encontrar a 
melhor opção para o seu filho.</p>
                                                 
                        <div class="image fit">
                            <img src="imagens/aula.jpg "alt=""  width="300" height="720" />
                        </div>


                    </div>
                </div>
            </div>
            <footer id="footer">
                <div class="container">

                </div>
                <div class="copyright">
                    <a href="/index.php" ><img src="imagens/iconesite.png" alt="" /></a><br>
                    &copy; All rights reserved to BIT.
                </div>
            </footer>
            
            <!-- Scripts -->
            <script src="assets/js/jquery.min.js"></script>
            <script src="assets/js/jquery.scrollex.min.js"></script>
            <script src="assets/js/skel.min.js"></script>
            <script src="assets/js/util.js"></script>
            <script src="assets/js/main.js"></script>
        </div>

    </body>
</html>