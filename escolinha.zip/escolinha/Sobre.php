<!DOCTYPE html>

<html>
    <head>
        <title>Jardim da alegria</title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" href="assets/css/main1.css" />
    </head>


    <body class="subpage">
        <div id="interface">
            <!-- Header -->
            <header id="header">

                <div class="logo"><a href="index.php"><span>jardim da alegria</span></a></div>
                <a href="#menu">Menu</a>
            </header>

            

            <!-- Nav -->
            <nav id="menu">

                <ul class="links">
                    
                    <li><a href="index.php">Home</a></li>
                    <li><a href="Login.php">Login</a></li>               
                   
                </ul>
            </nav>
            <div>
                <div class="box">

                    <div class="content">
                        <header class="align-center">
                            <p></p>
                            <h2></h2>
                        </header>
                        <style>
                            p{
                                text-align: justify;
                                text-align: center;
                            }
                           
                        </style>
                        <p style="text-align: justify">Bem-vindo ao site da nossa escola infantil Jardim da Alegria!</p>
                        <p style="text-align: justify"> Nosso compromisso é oferecer um ambiente acolhedor e seguro para crianças a partir de 3 meses até 5 anos de idade, onde elas possam crescer, aprender 
                        e se desenvolver de forma saudável e feliz. Nossa equipe é formada por profissionais dedicados e qualificados, que estão sempre prontos para oferecer o melhor cuidado 
                        e atenção às crianças. Temos uma proposta pedagógica inovadora, baseada em valores como respeito, responsabilidade e cooperação, que busca estimular o desenvolvimento cognitivo, 
                        motor,socioafetivo e cultural dos nossos pequenos.Oferecemos uma estrutura completa e adequada às necessidades das crianças, com salas de aula amplas e arejadas, 
                        espaços de lazer e recreação, alimentação balanceada e saudável, e atividades extracurriculares que complementam o processo educativo.Aqui, a aprendizagem é feita de forma 
                        lúdica e criativa, através de atividades que estimulam a imaginação, a curiosidade e a descoberta. Acreditamos que a educação infantil é uma etapa fundamental na formação das 
                        crianças, por isso nos esforçamos para proporcionar uma experiência educacional de qualidade e que seja significativa para o futuro delas.Se você procura uma escola infantil que 
                        ofereça um ambiente acolhedor, seguro e de excelência em educação, você veio ao lugar certo. 
</p>  <p>Agende uma visita e venha conhecer a nossa escola! </p>
                                                 
                        <div class="image fit">
                            <img src="imagens/TelaSobre.png" alt=""  width="360" height="500" />
                        </div>

                    </div>
                </div>
            </div>
            <footer id="footer">
                <div class="container">

                </div>
                <div class="copyright">
                    <a href="index.php" ><img src="imagens/iconesite.png" alt="" /></a><br>
                    &copy; All rights reserved to BIT.
                </div>
            </footer>
            
            <!-- Scripts -->
            <script src="assets/js/jquery.min.js"></script>
            <script src="assets/js/jquery.scrollex.min.js"></script>
            <script src="assets/js/skel.min.js"></script>
            <script src="assets/js/util.js"></script>
            <script src="assets/js/main.js"></script>
        </div>

    </body>
</html>