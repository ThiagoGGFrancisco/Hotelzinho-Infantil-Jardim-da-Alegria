<?php
session_start();
include('protect.php');
?>

<!DOCTYPE html>
<html lang="pt-br"></html>
<head>
<meta charset="UTF-8">     
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="assets/css/main1.css" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<style type="text/css">
@font-face {
font-family: nicesugar;
src: url(Nice\ Sugar.ttf)
}
</style>
 
</head>
<title>Jardim da alegria</title>


     
<body class="subpage">
        

            <!-- Header -->
           
            <header id="header">
              <div class="logo hide-logo"><a href="index.php"><img src="imagens/iconesite.png" alt="" /></a><br></div>

              
              <a href="#menu">Menu</a>

            </header>
    <!-- Nav  menu -->
    <nav id="menu">

        <ul class="links">
            <br>
              <h4>Seja bem-vindo, <u> <?php echo $_SESSION['nome'] ?></u></h4>
             <br>
             <li > <a href="painel.php">Avisos e Vídeos Educacionais</a> </li>
             <li > <a href="myatividade.php">Minhas Atividades</a> </li>
            <li ><a href="rematricula.php">Rematrícula</a> </li>
            
         <li> <a href="https://calendar.google.com/calendar/u/1/r/week/2023/5/10" target="_blank"> Agenda </a> </li>
            <li > <a href="https://api.whatsapp.com/send?phone=5519987075090&app" target="_blank"
                                > Falar com a direção </a></li>
            <li> <a href="sair.php">Sair</a>  </li><br>
           
        </ul>
    </nav>

  <br><br>
        </style>

</head>
<title>Jardim da alegria</title>


     
<body class="subpage">
        <div id="interface">

            <!-- Header -->
           
            <header id="header">
              <div class="logo"><a href=""><span>Jardim da alegria</span></a></div>
              
              <a href="#menu">Menu</a>

            </header>
    <!-- Nav  menu -->
    <nav id="menu">

        <ul class="links">
             <h4>Seja bem-vindo, <u> <?php echo $_SESSION['nome'] ?></u></h4><br>
          <li><a href="rematricula.php"> Rematrícula </a>  </li>
           <li><a href="painel.php"> Cadastro de Atividade </a>  </li>
           <li> <a href="https://calendar.google.com/calendar/u/1/r?pli=1"target="_blank" >
                Agenda</a> </li>
            <li><a href="https://api.whatsapp.com/send?phone=5519987075090&app" target="_blank"> Falar com a Direção </a>  </li>
            <li> <a href="sair.php">Sair</a>  </li><br>
           
        </ul>
        </nav>

 
   
<div class="content"> 
  <div class="card">
  <div class="container mt-5">
  <div class="card-header bg-info">
 
 <h4 class="text-center text-light">PESQUISA DE MATRÍCULA:</h4><br>
 </div
</div>
<form name="" action="" method="POST">
<label for="email" class="labelInput">E-MAIL:</label>             
<div class="inputBox">
<input type="email" name="email" id="email" class="inputUser" required placeholder="E-mail do responsavel " />
</div><br>
<input type="submit" name="enviar" value="PESQUISAR">
</form>
</div>
</div>
</div>
<br>

 
<?php

 include_once("conexao.php");
 
 $pesquisa = $_POST['email'];
?>
<br><br>

<div class="content"> 
  <div class="card"
  <div class="container mt-5">
 

<?php
 $sql = "SELECT * FROM inscricao WHERE email = '$pesquisa' ORDER BY id DESC" ;
 $resultado = mysqli_query($conexao,$sql) or die("Erro ao retornar dados");
 
 while ($registro = mysqli_fetch_array($resultado))
 {
    $id = $registro['id'];
     $turma = $registro['turma'];
   $periodo = $registro['periodo'];
   $nome = $registro['nome'];
   $email = $registro['email'];
   $crianca = $registro['crianca'];
   echo "<tr>";
   
 }
 mysqli_close($conexao);
 echo "</table>";
?>
       
 </div>

   <?php
    include_once('conexao.php');

    if(!empty($_GET['email']))
    {
        $id = $_GET['email'];
        $sqlSelect = "SELECT * FROM inscricao WHERE email=$email";
        $result = $conexao->query($sqlSelect);
        if($result->num_rows > 0)
        {
            while($user_data = mysqli_fetch_assoc($result))
            {
                $id = $user_data['id'];
                $nome = $user_data['nome'];
                $email = $user_data['email'];
                $telefone = $user_data['telefone'];
             
              
            }
        }
        else
        {
            header('Location:');
        }
    }
    else
    {
        header('Location: ');
    }
?>

<br>
     <div class="content"> 
        <form action="" method="POST">
            <fieldset>
    <div class="col-12">
    <div class="card">
    <div class="card-header bg-warning">
    <h4 class="text-center text-light">PREENCHA SUA REMATRÍCULA: </h4>
          </div>      
                <div class="inputBox">
                    <h3 class="text-center text-light"><label for="nome" class="labelInput">ID: <?php echo $id;?></label></h3>
                </div>
               
             <label for="turma" class="labelInput">TURMA:  <?php echo $turma;?></label>
<select name="turma" type="text" name="turma" id="turma" class="inputUser" required >
                <option value="">Selecione a turma por idade</option>
                <option value=" Berçário"> Berçário + 3 meses </option>
                <option value="Maternal"> Maternal + 1 ano</option>
                <option value="Maternal II">Maternal II   de 2 até 3 anos</option>
                <option value="Pré-escola I">Pré-escola I até 4 anos</option>
                <option value="Pré-escola II">Pré-escola II até 5 anos</option>
                
</select><br>

<label for="periodo" class="labelInput">PERÍODO:  <?php echo $periodo;?></label>
<select name="periodo" type="text" name="periodo" id="periodo" class="inputUser" required >
                <option value="">Selecione o período do seu interesse</option>
                <option value="Integral">Integral 7h-17h20</option>
                <option value="Meio período -Manhã">Meio período -Manhã 7h-12h20 </option>
                <option value="Meio período- Tarde">Meio período- Tarde 13h-17h20</option>
                

                
</select><br>
                <div class="inputBox">
                       <label for="nome" class="labelInput">NOME COMPLETO CRIANÇA:   <?php echo $nome;?></label>
                    <input type="text" name="nome" id="nome" class="inputUser" value=<?php echo $nome;?> Nome>
                 
                </div><br>
                
                <div class="inputBox">
                    <label for="email" class="labelInput">Email:  <?php echo $email;?></label>
                    <input type="email" name="email" id="email" class="inputUser" value=<?php echo $email;?> E-mail>
                    
                </div><br>
           
                <label for="telefone" class="labelInput">TELEFONE 1: </label>
<div class="inputBox">
    <input type="tel" name="telefone" id="telefone" class="inputUser"maxlength="12" required placeholder="(00)00000-0000"/>
</div>
                <br>
                 
				<input type="hidden" name="id" value=<?php echo $id;?>>
                <input type="submit" name="update" id="submit"value="CONFIRMAR REMATRÍCULA">
            </fieldset>
        </form>
    </div>
    </div>
<br>


<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
            <script src="assets/js/jquery.scrollex.min.js"></script>
            <script src="assets/js/skel.min.js"></script>
            <script src="assets/js/util.js"></script>
            <script src="assets/js/main.js"></script>
</html>
</boby>

<br><br>
