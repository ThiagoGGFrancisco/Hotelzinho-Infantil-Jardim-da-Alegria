
<?php
session_start();
include('protect.php');
?>

<!DOCTYPE html>
<html lang="pt-br"></html>
<head>
<meta charset="UTF-8">     
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="assets/css/main1.css" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<style type="text/css">
@font-face {
font-family: nicesugar;
src: url(Nice\ Sugar.ttf)
}
</style>
 
</head>
<title>Jardim da alegria</title>


     
<body class="subpage">
        <div id="interface">

            <!-- Header -->
            
            <header id="header">
              <div class="logo"><a href=""><span>Jardim da alegria</span></a></div>
              
              <a href="#menu">Menu</a>

            </header>
    <!-- Nav  menu -->
    <nav id="menu">

        <ul class="links">
            <h4>Bem vindo <u> <?php echo $_SESSION['nome'] ?></u></h4>
            <li><a href=""> Home</a></li>
            <li><a href="lista.php">Lista</a></li>
            <li> <a href="sair.php">Sair</a>  </li>
            <?php

date_default_timezone_set('America/Sao_Paulo');
$hora = date('h:i:s A');
$mes1=array(jan,feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec);
$mes2=array(Jan,Fev,Mar,Abr,Mai,Jun,Jul,Ago,Set,Out,Nov,Dez);
$mestexto=array(Janeiro,Fevereiro,Março,Abril,Maio,Junho,Julho,Agosto,Setembro,Outubro,Novembro,Dezembro);
$hour=date('H');
$mestext=str_ireplace($mes1,$mestexto,date('d/M/Y'));
$data=str_ireplace($mes1,$mes2,date('d/M/Y'));

if ($hour < 12) echo "<span style=\"color:red;\">BOM DIA</span><BR>";
else if ($hour < 18) echo "<span style=\"color:green;\">BOA TARDE</span><BR>";
 else if ($hour < 24) echo "<span style=\"color:blue;\">BOA NOITE</span><BR>";
 
 echo("$data $hora <br> $mestext");

?>
        </ul> 
        </div><br><br>
    </nav>


        </style>
    
      
    
       <div class="content">                                      

        <div class="container mt-5">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header bg-dark">
                            <h4 class="text-center text-light">Cadastro Geral.</h4>
                        </div>
                        <div class="card-body">
                            <form action="insert.php" method="post" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="username" class="form-label">Nome</label>
                                            <input type="text" class="form-control" id="username" name="user_name" minlength="10"" maxlength="50" placeholder="Digita seu Name"required="required" autocomplete="off"pattern="[a-zA-Z\s]+$" />
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="useremail" class="form-label">Email</label>
                                            <input type="email" class="form-control" id="useremail" name="user_email" maxlength="50" placeholder="Digita seu Email" required="required"autocomplete="off">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="usercontact" class="form-label">Telefone</label>
                                            <input type="tel"required="required"minlength="10" maxlength="12" class="form-control" id="usercontact" name="user_contact" placeholder="Digita seu telefone" autocomplete="off "pattern="[0-9]{2}[0-9]{5,6}[0-9]{4,5}$" />
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">      
                                            <label for="usercontact" class="form-label">Níveis de acesso</label>
                                            <input type="number"   min="0" max="2"class="form-control" maxlength="1" id="usercontact" name="user_adm" placeholder="Níveis 0, 1 e 2. " autocomplete="off"required="required" pattern="[0-9]+$" />
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="userpassword" class="form-label">Senha</label>
                                            <input type="password" class="form-control"  minlength="6"maxlength="10"id="userpassword" name="user_password" placeholder="senha" required="required" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="userpassword" class="form-label">Confirma senha</label>
                                            <input type="password" class="form-control"  minlength="6"maxlength="10"id="userpassword" name="confirm_user_password" placeholder="confirma senha"required="required" autocomplete="off">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6"></div>
                                    <div class="col-md-6">
                                        <button type="submit" name="submit_btn" class="btn bg-dark text-light submit_button"><b>Cadastro</b></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
            
        <style>
        table  td, table th{
        vertical-align:middle;
        text-align:right;
        padding:20px!important;
        }
    </style>
</head><br><br><br><br>

 
 
 <div class="content"> 
  <div class="card">
  <div class="container mt-5">
  <div class="card-header bg-dark">
 
 <h4 class="text-center text-light">Pesquisa</h4><br>
 </div
</div>
<form name="Cadastro" action="" method="POST">
<label>Selecione o Cliente:</label>
<select name="adm">
  <option value="0">Cliente</option>
  <option value="1">Colaborador</option>
  <option value="2">ADM</option>
</select><br>
<input type="submit" name="enviar" value="Enviar">
</form>
</div>
</div>
</div>
<br>
<?php

 include_once("conexao.php");
 
 $pesquisa = $_POST['adm'];
?><br><br>
  <div class="card">
<table class="table table-bordered">
<thead>
 <tr>
 <th>ID</th>
 <th>Nome</th>
 <th>Email</th>
 <th>Nível</th>
 </tr>
  </thead>
<?php
 $sql = "SELECT * FROM cadastro WHERE adm = '$pesquisa' ORDER BY id DESC" ;
 $resultado = mysqli_query($conexao,$sql) or die("Erro ao retornar dados");
 
 while ($registro = mysqli_fetch_array($resultado))
 {
    $id = $registro['id'];
   $nome = $registro['nome'];
   $email = $registro['email'];
   $nivel = $registro['adm'];
   echo "<tr>";
   echo "<td>".$id."</td>";
   echo "<td>".$nome."</td>";
   echo "<td>".$email."</td>";
   echo "<td>".$nivel."</td>";
   echo "</tr>";
 }
 mysqli_close($conexao);
 echo "</table>";
?>
        </tbody>
        </table>
 </div>
</body>
</script>
</html>
<!-- Scripts -->
            <script src="assets/js/jquery.min.js"></script>
            <script src="assets/js/jquery.scrollex.min.js"></script>
            <script src="assets/js/skel.min.js"></script>
            <script src="assets/js/util.js"></script>
            <script src="assets/js/main.js"></script>

</div>                
</div>
</div> 
<br>









</body>
</html>